# Efficiency Metrics
Metrics accounting system for evaluating the effectiveness of specialists and teams in project tasks
